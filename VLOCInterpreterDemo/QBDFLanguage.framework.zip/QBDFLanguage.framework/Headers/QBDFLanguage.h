//
//  QBDFLanguage.h
//  QBDFLanguage
//
//  Created by fatboyli on 2017/6/9.
//  Copyright © 2017年 fatboyli. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QBDFLanguage/QBDFScriptInterpreter.h>
#import <QBDFLanguage/QBDFVM.h>

//! Project version number for QBDFLanguage.
FOUNDATION_EXPORT double QBDFLanguageVersionNumber;

//! Project version string for QBDFLanguage.
FOUNDATION_EXPORT const unsigned char QBDFLanguageVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <QBDFLanguage/PublicHeader.h>


