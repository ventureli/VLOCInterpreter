//
//  VLOCInterpreterFramework.h
//  VLOCInterpreterFramework
//
//  Created by fatboyli on 2017/10/26.
//  Copyright © 2017年 ventureli. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <VLOCInterpreterFramework/VLOCCompiler.h>
#import <VLOCInterpreterFramework/VLOCVM.h>
//! Project version number for VLOCInterpreterFramework.
FOUNDATION_EXPORT double VLOCInterpreterFrameworkVersionNumber;

//! Project version string for VLOCInterpreterFramework.
FOUNDATION_EXPORT const unsigned char VLOCInterpreterFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VLOCInterpreterFramework/PublicHeader.h>


